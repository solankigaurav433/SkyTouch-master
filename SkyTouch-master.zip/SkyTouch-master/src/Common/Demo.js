import { View, Text } from 'react-native';
import React from 'react';

const Demo = () => {
  return (
    <View>
      <Text>Demo</Text>
    </View>
  );
};

export default Demo;
